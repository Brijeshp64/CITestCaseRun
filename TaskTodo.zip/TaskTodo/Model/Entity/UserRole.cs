﻿namespace TaskTodo.Model.Entity
{
    public enum UserRole
    { 
            Admin= 1,
            user = 2
        
    }
}
