﻿namespace TaskTodo.Model.Entity
{
    public class Notification
    {
        public int UserId { get; set; }
        public string ConnectionId { get; set; }
        public string Message { get; set; }
    }
}
