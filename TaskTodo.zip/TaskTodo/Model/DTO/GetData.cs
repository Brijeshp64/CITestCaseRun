﻿using ProtoBuf;

namespace TaskTodo.Model.DTO
{
    [ProtoContract(SkipConstructor = true)]
    public class GetData
    {
        [ProtoMember(1)]
        public int Id { get; set; }
        [ProtoMember(2)]

        public string Title { get; set; } = null!;
        [ProtoMember(3)]

        public string Description { get; set; } = null!;
        [ProtoMember(4)]

        public bool IsCompleted { get; set; }
        [ProtoMember(5)]

        public DateTime CreatedDate { get; set; } = DateTime.Now;
        [ProtoMember(6)]

        public DateTime? DueDate { get; set; }
        [ProtoMember(7)]
        public bool Flag { get; set; }
    }
}
