﻿using System.Threading.Tasks;

namespace TaskTodo.INotification
{
    public interface Inotification
    {
        Task ReciveNotification(string meessage);
    }
}
